// Raika Time Tracker - Background Service Worker
// 追踪标签页停留时间，每5分钟批量上报到 GitHub

const GITHUB_TOKEN = ""; // 安装后填写
const GITHUB_OWNER = "yuentschiw";
const GITHUB_REPO = "personal-task-dashboard";
const GITHUB_FILE = "time-tracking-data.json";
const FLUSH_INTERVAL_MINUTES = 5;
const IDLE_THRESHOLD_SECONDS = 120; // 2分钟无操作视为idle

// 内存状态
let activeTabId = null;
let activeTabUrl = null;
let activeTabTitle = null;
let sessionStart = null; // 当前tab开始计时的时间
let pendingRecords = []; // 待上报的记录
let isIdle = false;
let pausedAt = null; // idle开始时间

// ─── 工具函数 ───────────────────────────────────────────────

function normalizeUrl(url) {
  try {
    const u = new URL(url);
    // 过滤无意义页面
    if (["chrome:", "chrome-extension:", "about:", "edge:"].includes(u.protocol)) return null;
    if (u.hostname === "newtab") return null;
    return url;
  } catch {
    return null;
  }
}

function classifyUrl(url, title) {
  if (!url) return { category: "unknown", label: title || url };
  
  try {
    const u = new URL(url);
    const host = u.hostname;
    const path = u.pathname;

    // REDoc 文档识别
    if (host.includes("xiaohongshu.com") && path.includes("/doc/")) {
      const docId = path.split("/doc/")[1]?.split("/")[0] || "unknown";
      return { category: "redoc", label: `REDoc: ${title || docId}`, docId };
    }

    // Hi IM
    if (host.includes("xiaohongshu.com") && (path.includes("/im") || path.includes("/chat"))) {
      return { category: "hi-im", label: `Hi: ${title || "对话"}` };
    }

    // 小红书内部系统
    if (host.includes("xiaohongshu.com") || host.includes("xhscdn.com")) {
      return { category: "xhs-internal", label: title || host + path };
    }

    // GitHub
    if (host.includes("github.com")) {
      return { category: "github", label: `GitHub: ${title || path}` };
    }

    // 通用
    return { category: "web", label: title || host };
  } catch {
    return { category: "web", label: title || url };
  }
}

function now() {
  return Date.now();
}

function isoNow() {
  return new Date().toISOString();
}

// ─── 计时逻辑 ───────────────────────────────────────────────

function startSession(tabId, url, title) {
  const normalized = normalizeUrl(url);
  if (!normalized) return;
  
  activeTabId = tabId;
  activeTabUrl = normalized;
  activeTabTitle = title;
  sessionStart = now();
  isIdle = false;
  pausedAt = null;
}

function endSession(reason = "switch") {
  if (!activeTabUrl || !sessionStart) return;
  
  let durationMs;
  if (isIdle && pausedAt) {
    // 从pausedAt到现在不算，用pausedAt - sessionStart
    durationMs = pausedAt - sessionStart;
  } else {
    durationMs = now() - sessionStart;
  }
  
  const durationSeconds = Math.floor(durationMs / 1000);
  
  // 过滤太短的（< 5秒）
  if (durationSeconds < 5) {
    activeTabUrl = null;
    sessionStart = null;
    return;
  }

  const classified = classifyUrl(activeTabUrl, activeTabTitle);
  
  const record = {
    timestamp: isoNow(),
    url: activeTabUrl,
    title: activeTabTitle,
    durationSeconds,
    reason,
    ...classified
  };
  
  pendingRecords.push(record);
  console.log("[TimeTracker] Record:", record);
  
  // 超过20条立刻flush
  if (pendingRecords.length >= 20) {
    flushToGitHub();
  }
  
  activeTabUrl = null;
  sessionStart = null;
}

// ─── Tab 事件监听 ────────────────────────────────────────────

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  // 结束上一个tab的计时
  endSession("tab-switch");
  
  try {
    const tab = await chrome.tabs.get(tabId);
    startSession(tabId, tab.url, tab.title);
  } catch (e) {
    console.warn("[TimeTracker] Cannot get tab:", e);
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId !== activeTabId) return;
  if (changeInfo.status !== "complete") return;
  
  // 当前tab导航到新URL
  if (changeInfo.url && changeInfo.url !== activeTabUrl) {
    endSession("navigation");
    startSession(tabId, tab.url, tab.title);
  } else if (changeInfo.title && changeInfo.title !== activeTabTitle) {
    activeTabTitle = changeInfo.title;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === activeTabId) {
    endSession("tab-closed");
  }
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    // 浏览器失去焦点
    if (!isIdle) {
      isIdle = true;
      pausedAt = now();
    }
  } else {
    // 浏览器重新获得焦点
    if (isIdle) {
      isIdle = false;
      // 把暂停时间加回去（修正 sessionStart）
      if (pausedAt && sessionStart) {
        const idleDuration = now() - pausedAt;
        sessionStart += idleDuration;
      }
      pausedAt = null;
    }
  }
});

// ─── Idle 检测 ───────────────────────────────────────────────

chrome.idle.setDetectionInterval(IDLE_THRESHOLD_SECONDS);

chrome.idle.onStateChanged.addListener((state) => {
  if (state === "idle" || state === "locked") {
    if (!isIdle) {
      isIdle = true;
      pausedAt = now();
    }
  } else if (state === "active") {
    if (isIdle) {
      isIdle = false;
      if (pausedAt && sessionStart) {
        const idleDuration = now() - pausedAt;
        sessionStart += idleDuration;
      }
      pausedAt = null;
    }
  }
});

// ─── 定时上报 ─────────────────────────────────────────────────

chrome.alarms.create("flush", { periodInMinutes: FLUSH_INTERVAL_MINUTES });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush") {
    // 先把当前正在计时的tab记录一个快照（不结束）
    if (activeTabUrl && sessionStart && !isIdle) {
      const elapsed = Math.floor((now() - sessionStart) / 1000);
      if (elapsed >= 5) {
        const classified = classifyUrl(activeTabUrl, activeTabTitle);
        pendingRecords.push({
          timestamp: isoNow(),
          url: activeTabUrl,
          title: activeTabTitle,
          durationSeconds: elapsed,
          reason: "snapshot",
          ...classified
        });
        // 重置计时起点
        sessionStart = now();
      }
    }
    flushToGitHub();
  }
});

// ─── GitHub 上报 ─────────────────────────────────────────────

async function flushToGitHub() {
  if (pendingRecords.length === 0) return;
  if (!GITHUB_TOKEN) {
    console.warn("[TimeTracker] GitHub token not set, storing locally");
    // 存到 chrome.storage 作为备份
    const { localBuffer = [] } = await chrome.storage.local.get("localBuffer");
    localBuffer.push(...pendingRecords);
    await chrome.storage.local.set({ localBuffer });
    pendingRecords = [];
    return;
  }
  
  const toFlush = [...pendingRecords];
  pendingRecords = [];
  
  try {
    // 1. 读取现有文件（获取 SHA）
    const getResp = await fetch(
      `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_FILE}`,
      { headers: { Authorization: `token ${GITHUB_TOKEN}`, Accept: "application/vnd.github.v3+json" } }
    );
    
    let existingRecords = [];
    let sha = null;
    
    if (getResp.ok) {
      const getJson = await getResp.json();
      sha = getJson.sha;
      const decoded = JSON.parse(atob(getJson.content.replace(/\n/g, "")));
      existingRecords = decoded.records || [];
    }
    
    // 2. 合并新记录
    const merged = {
      records: [...existingRecords, ...toFlush],
      lastUpdated: isoNow(),
      extensionVersion: "1.0.0"
    };
    
    // 只保留最近30天
    const cutoff = Date.now() - 30 * 24 * 3600 * 1000;
    merged.records = merged.records.filter(r => new Date(r.timestamp).getTime() > cutoff);
    
    // 3. 写回 GitHub
    const content = btoa(unescape(encodeURIComponent(JSON.stringify(merged, null, 2))));
    const putBody = {
      message: `[time-tracker] ${toFlush.length} records @ ${isoNow()}`,
      content,
      ...(sha ? { sha } : {})
    };
    
    const putResp = await fetch(
      `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_FILE}`,
      {
        method: "PUT",
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(putBody)
      }
    );
    
    if (!putResp.ok) {
      const errText = await putResp.text();
      console.error("[TimeTracker] GitHub PUT failed:", errText);
      pendingRecords.unshift(...toFlush); // 放回重试
    } else {
      console.log(`[TimeTracker] Flushed ${toFlush.length} records to GitHub`);
    }
  } catch (e) {
    console.error("[TimeTracker] Flush error:", e);
    pendingRecords.unshift(...toFlush); // 放回重试
  }
}

// ─── 消息通信（popup ↔ background）─────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_STATUS") {
    // 计算今日各类统计
    const today = new Date().toISOString().split("T")[0];
    const todayRecords = pendingRecords.filter(r => r.timestamp.startsWith(today));
    
    // 汇总 by label
    const labelMap = {};
    for (const r of todayRecords) {
      const key = r.label || r.url;
      if (!labelMap[key]) labelMap[key] = { label: key, totalSeconds: 0, category: r.category };
      labelMap[key].totalSeconds += r.durationSeconds;
    }
    const todayStats = Object.values(labelMap).sort((a, b) => b.totalSeconds - a.totalSeconds);
    
    const elapsed = (activeTabUrl && sessionStart && !isIdle)
      ? Math.floor((now() - sessionStart) / 1000)
      : 0;
    
    const classified = activeTabUrl ? classifyUrl(activeTabUrl, activeTabTitle) : {};
    
    sendResponse({
      url: activeTabUrl,
      title: activeTabTitle,
      category: classified.category,
      label: classified.label,
      elapsedSeconds: elapsed,
      isIdle,
      pendingCount: pendingRecords.length,
      todayStats
    });
  } else if (msg.type === "FORCE_FLUSH") {
    // 快照当前tab
    if (activeTabUrl && sessionStart && !isIdle) {
      const elapsed = Math.floor((now() - sessionStart) / 1000);
      if (elapsed >= 5) {
        const classified = classifyUrl(activeTabUrl, activeTabTitle);
        pendingRecords.push({
          timestamp: isoNow(),
          url: activeTabUrl,
          title: activeTabTitle,
          durationSeconds: elapsed,
          reason: "manual-flush",
          ...classified
        });
        sessionStart = now();
      }
    }
    flushToGitHub().then(() => sendResponse({ ok: true }));
    return true; // async
  }
  return false;
});

// ─── 初始化 ───────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async () => {
  console.log("[TimeTracker] Installed. Ready.");
  // 获取当前活跃tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) startSession(tab.id, tab.url, tab.title);
});

chrome.runtime.onStartup.addListener(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) startSession(tab.id, tab.url, tab.title);
});

// 扩展卸载前flush
chrome.runtime.onSuspend.addListener(() => {
  endSession("suspend");
  flushToGitHub();
});
